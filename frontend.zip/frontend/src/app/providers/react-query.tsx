import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactNode } from "react";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 30_000,
    },
  },
});

export function ReactQueryProvider({ children }: { children: ReactNode }) {
  console.log("queryProvider")
  return (
    <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
  );
}
