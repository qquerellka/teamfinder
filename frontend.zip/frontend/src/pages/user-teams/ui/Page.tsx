

export const UserTeamsPage = () => {


    return (
        <div className="">Мои команды</div>
    )
}

export default UserTeamsPage;