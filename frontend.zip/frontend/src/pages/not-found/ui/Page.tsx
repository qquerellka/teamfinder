export const NotFound = () => {
  return <div className="">No page</div>;
};

export default NotFound;
