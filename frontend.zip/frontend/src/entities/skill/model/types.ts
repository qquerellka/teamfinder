export interface Skill {
  id: number;
  slug: string;
  name: string;
}


export interface SkillDTO {
  id: number;
  slug: string;
  name: string;
}