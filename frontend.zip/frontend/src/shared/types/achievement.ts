

export interface Achievement {
    id: string;
    userId: string;
    name: string;
    role: string;
    place: string;
    hackLink: string
}