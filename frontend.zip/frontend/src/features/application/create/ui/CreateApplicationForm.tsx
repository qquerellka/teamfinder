

export const CreateApplicationForm = () => {
    return (
        <div className=""></div>
    )
}