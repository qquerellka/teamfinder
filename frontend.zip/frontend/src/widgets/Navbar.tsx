import { FC } from "react";
import styled from "styled-components";
import { Tabbar } from "@telegram-apps/telegram-ui";
import { NavLink } from "react-router-dom";
import { paths } from "@/shared/routing/paths";
import { SIcon } from "@/shared/ui/SIcon";
import type { IconName } from "@/shared/ui/SIcon";

interface NavItem {
  id: number;
  name: string;
  icon: IconName;
  path: string;
}
const NAV: NavItem[] = [
  { id: 1, name: "hackathons", icon: "hackNav", path: paths.hackathons },
  {
    id: 2,
    name: "applications",
    icon: "teamNav",
    path: paths.applications,
  },
  {
    id: 3,
    name: "teams",
    icon: "appNav",
    path: paths.teams,
  },
  { id: 4, name: "profile", icon: "profile", path: paths.profile },
];

export const Navbar: FC = () => (
  <STabbar>
    {NAV.map(({ id, icon, path }) => (
      <SItem key={id}>
        <NavLink
          to={path}
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          <SIcon name={icon} size={28} />
        </NavLink>
      </SItem>
    ))}
  </STabbar>
);

const STabbar = styled(Tabbar)`
  position: static;
  box-shadow: none;
  bottom: 0;

  display: flex;
  justify-content: space-between;
  padding: 0.875rem 2rem;
  background: transparent;
`;

const SItem = styled(Tabbar.Item)`
  display: block;
  flex: unset;
  padding: 0;
  line-height: 1;
  div {
    min-width: auto;
    padding: 0;
    margin: 0;
  }
`;
