from backend.presentations.app import create_app
from fastapi import FastAPI

# app = create_app()
app: FastAPI = create_app() 